/**
 * 부동산금융투자를 위한 머신러닝 모델 - 메인 스크립트
 * 작성일: 2025년 5월 18일
 */

// DOM 요소
const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
const mobileMenu = document.querySelector('.mobile-menu');
const mobileMenuClose = document.querySelector('.mobile-menu-close');
const accordionHeaders = document.querySelectorAll('.accordion-header');
const tabButtons = document.querySelectorAll('.tab-btn');
const resultTabs = document.querySelectorAll('.result-tab');
const refTabs = document.querySelectorAll('.ref-tab');
const modelDetailButtons = document.querySelectorAll('.btn-detail');
const modalClose = document.querySelector('.modal-close');
const faqQuestions = document.querySelectorAll('.faq-question');
const sliderPrev = document.querySelector('.slider-prev');
const sliderNext = document.querySelector('.slider-next');
const sliderDots = document.querySelectorAll('.dot');

// 모델 데이터
let modelsData = {};

// 페이지 로드 시 초기화
document.addEventListener('DOMContentLoaded', function() {
  // 모바일 메뉴 이벤트 리스너
  setupMobileMenu();
  
  // 아코디언 이벤트 리스너
  setupAccordions();
  
  // 탭 이벤트 리스너
  setupTabs();
  
  // 모델 상세 정보 모달 이벤트 리스너
  setupModelDetailModal();
  
  // FAQ 이벤트 리스너
  setupFAQ();
  
  // 슬라이더 이벤트 리스너
  setupSlider();
  
  // 모델 데이터 로드
  loadModelsData();
  
  // 시뮬레이션 초기화
  initSimulation();
  
  // 스크롤 이벤트 리스너
  setupScrollEvents();
  
  // 콘솔에 로드 완료 메시지
  console.log('부동산금융투자를 위한 머신러닝 모델 웹페이지가 로드되었습니다.');
});

// 모바일 메뉴 설정
function setupMobileMenu() {
  mobileMenuToggle.addEventListener('click', function() {
    mobileMenu.classList.add('active');
  });
  
  mobileMenuClose.addEventListener('click', function() {
    mobileMenu.classList.remove('active');
  });
  
  // 모바일 메뉴 외부 클릭 시 닫기
  document.addEventListener('click', function(event) {
    if (!mobileMenu.contains(event.target) && !mobileMenuToggle.contains(event.target) && mobileMenu.classList.contains('active')) {
      mobileMenu.classList.remove('active');
    }
  });
}

// 아코디언 설정
function setupAccordions() {
  accordionHeaders.forEach(header => {
    header.addEventListener('click', function() {
      const accordionItem = this.parentElement;
      accordionItem.classList.toggle('active');
    });
  });
}

// 탭 설정
function setupTabs() {
  // 적용 사례 탭
  tabButtons.forEach(button => {
    button.addEventListener('click', function() {
      const tabId = this.dataset.tab;
      
      // 활성 탭 버튼 업데이트
      tabButtons.forEach(btn => btn.classList.remove('active'));
      this.classList.add('active');
      
      // 활성 탭 콘텐츠 업데이트
      const tabPanes = document.querySelectorAll('.tab-pane');
      tabPanes.forEach(pane => pane.classList.remove('active'));
      document.getElementById(tabId).classList.add('active');
    });
  });
  
  // 결과 탭
  resultTabs.forEach(tab => {
    tab.addEventListener('click', function() {
      const resultId = this.dataset.result;
      
      // 활성 탭 버튼 업데이트
      resultTabs.forEach(t => t.classList.remove('active'));
      this.classList.add('active');
      
      // 활성 결과 패널 업데이트
      const resultPanes = document.querySelectorAll('.result-pane');
      resultPanes.forEach(pane => pane.classList.remove('active'));
      document.getElementById(`${resultId}-result`).classList.add('active');
    });
  });
  
  // 참고자료 탭
  refTabs.forEach(tab => {
    tab.addEventListener('click', function() {
      const refId = this.dataset.ref;
      
      // 활성 탭 버튼 업데이트
      refTabs.forEach(t => t.classList.remove('active'));
      this.classList.add('active');
      
      // 활성 참고자료 패널 업데이트
      const refPanes = document.querySelectorAll('.ref-pane');
      refPanes.forEach(pane => pane.classList.remove('active'));
      document.getElementById(refId).classList.add('active');
    });
  });
}

// 모델 상세 정보 모달 설정
function setupModelDetailModal() {
  const modal = document.getElementById('model-detail-modal');
  
  modelDetailButtons.forEach(button => {
    button.addEventListener('click', function() {
      const modelId = this.dataset.model;
      openModelDetailModal(modelId);
    });
  });
  
  modalClose.addEventListener('click', function() {
    modal.classList.remove('active');
  });
  
  // 모달 외부 클릭 시 닫기
  window.addEventListener('click', function(event) {
    if (event.target === modal) {
      modal.classList.remove('active');
    }
  });
  
  // ESC 키로 모달 닫기
  document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape' && modal.classList.contains('active')) {
      modal.classList.remove('active');
    }
  });
}

// 모델 상세 정보 모달 열기
function openModelDetailModal(modelId) {
  const modal = document.getElementById('model-detail-modal');
  const modalTitle = document.getElementById('modal-title');
  const modalContent = document.getElementById('modal-content');
  
  // 모델 데이터가 로드되었는지 확인
  if (Object.keys(modelsData).length === 0) {
    modalTitle.textContent = '데이터 로딩 중...';
    modalContent.innerHTML = '<p>모델 데이터를 불러오는 중입니다. 잠시만 기다려주세요.</p>';
    modal.classList.add('active');
    
    // 데이터 로드 후 다시 시도
    loadModelsData().then(() => {
      openModelDetailModal(modelId);
    });
    return;
  }
  
  // 모델 데이터에서 해당 모델 찾기
  const model = modelsData.models.find(m => m.id === modelId);
  
  if (!model) {
    modalTitle.textContent = '모델 정보 없음';
    modalContent.innerHTML = '<p>해당 모델에 대한 정보를 찾을 수 없습니다.</p>';
    modal.classList.add('active');
    return;
  }
  
  // 모달 제목 설정
  modalTitle.textContent = `${model.name} (${model.type})`;
  
  // 모달 내용 생성
  let content = `
    <div class="model-detail">
      <div class="model-overview">
        <h3>개요</h3>
        <p>${model.fullDescription.overview}</p>
      </div>
      
      <div class="model-math">
        <h3>수학적 정의</h3>
        <div class="math-block">
          ${model.fullDescription.mathFormulation}
        </div>
      </div>
      
      <div class="model-advantages-disadvantages">
        <div class="model-advantages">
          <h3>장점</h3>
          <ul>
            ${model.fullDescription.advantages.map(adv => `<li>${adv}</li>`).join('')}
          </ul>
        </div>
        
        <div class="model-disadvantages">
          <h3>단점</h3>
          <ul>
            ${model.fullDescription.disadvantages.map(dis => `<li>${dis}</li>`).join('')}
          </ul>
        </div>
      </div>
      
      <div class="model-applications">
        <h3>부동산금융투자 적용 분야</h3>
        <ul>
          ${model.fullDescription.realEstateApplications.map(app => `<li>${app}</li>`).join('')}
        </ul>
      </div>
      
      <div class="model-code">
        <h3>코드 예시</h3>
        <pre><code class="language-python">${model.codeExample}</code></pre>
      </div>
      
      <div class="model-parameters">
        <h3>주요 파라미터</h3>
        <table class="academic-table">
          <thead>
            <tr>
              <th>파라미터</th>
              <th>설명</th>
              <th>기본값</th>
              <th>범위/옵션</th>
            </tr>
          </thead>
          <tbody>
            ${model.parameters.map(param => `
              <tr>
                <td>${param.name}</td>
                <td>${param.description}</td>
                <td>${param.default}</td>
                <td>${param.range ? `${param.range[0]} ~ ${param.range[1]}` : (param.options ? param.options.join(', ') : '')}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
      
      <div class="model-references">
        <h3>참고문헌</h3>
        <ul class="reference-list">
          ${model.references.map(ref => `
            <li>${ref.authors} (${ref.year}). ${ref.title}. ${ref.url !== '#' ? `<a href="${ref.url}" target="_blank">링크</a>` : ''}</li>
          `).join('')}
        </ul>
      </div>
    </div>
  `;
  
  modalContent.innerHTML = content;
  
  // MathJax 재렌더링
  if (typeof MathJax !== 'undefined') {
    MathJax.Hub.Queue(['Typeset', MathJax.Hub, modalContent]);
  }
  
  // 모달 표시
  modal.classList.add('active');
}

// FAQ 설정
function setupFAQ() {
  faqQuestions.forEach(question => {
    question.addEventListener('click', function() {
      const faqItem = this.parentElement;
      faqItem.classList.toggle('active');
    });
  });
}

// 슬라이더 설정
function setupSlider() {
  const slides = document.querySelectorAll('.idea-slide');
  let currentSlide = 0;
  
  // 초기 슬라이드 표시
  showSlide(currentSlide);
  
  // 이전 슬라이드 버튼
  if (sliderPrev) {
    sliderPrev.addEventListener('click', function() {
      currentSlide = (currentSlide - 1 + slides.length) % slides.length;
      showSlide(currentSlide);
    });
  }
  
  // 다음 슬라이드 버튼
  if (sliderNext) {
    sliderNext.addEventListener('click', function() {
      currentSlide = (currentSlide + 1) % slides.length;
      showSlide(currentSlide);
    });
  }
  
  // 도트 네비게이션
  sliderDots.forEach((dot, index) => {
    dot.addEventListener('click', function() {
      currentSlide = index;
      showSlide(currentSlide);
    });
  });
  
  // 슬라이드 표시 함수
  function showSlide(index) {
    slides.forEach(slide => slide.classList.remove('active'));
    sliderDots.forEach(dot => dot.classList.remove('active'));
    
    slides[index].classList.add('active');
    sliderDots[index].classList.add('active');
  }
  
  // 자동 슬라이드 (5초마다)
  setInterval(function() {
    currentSlide = (currentSlide + 1) % slides.length;
    showSlide(currentSlide);
  }, 5000);
}

// 모델 데이터 로드
async function loadModelsData() {
  try {
    const response = await fetch('data/models.json');
    modelsData = await response.json();
    console.log('모델 데이터 로드 완료:', modelsData.models.length + '개 모델');
    return modelsData;
  } catch (error) {
    console.error('모델 데이터 로드 오류:', error);
    return {};
  }
}

// 시뮬레이션 초기화
function initSimulation() {
  const runSimulationButton = document.getElementById('run-simulation');
  if (!runSimulationButton) return;
  
  runSimulationButton.addEventListener('click', function() {
    // 로딩 표시
    this.disabled = true;
    this.textContent = '시뮬레이션 실행 중...';
    
    // 파라미터 값 가져오기
    const modelSelect = document.getElementById('model-select');
    const dataSelect = document.getElementById('data-select');
    const learningRate = document.getElementById('param-learning-rate');
    const maxDepth = document.getElementById('param-max-depth');
    const nEstimators = document.getElementById('param-n-estimators');
    
    // 시뮬레이션 실행 (실제로는 서버에 요청하거나 TensorFlow.js 등으로 구현)
    setTimeout(function() {
      // 시뮬레이션 결과 표시 (예시)
      displaySimulationResults({
        model: modelSelect.value,
        data: dataSelect.value,
        params: {
          learning_rate: parseFloat(learningRate.value),
          max_depth: parseInt(maxDepth.value),
          n_estimators: parseInt(nEstimators.value)
        },
        metrics: {
          rmse: (Math.random() * 100 + 50).toFixed(2),
          mae: (Math.random() * 50 + 30).toFixed(2),
          r2: (Math.random() * 0.5 + 0.5).toFixed(4),
          time: (Math.random() * 5 + 1).toFixed(2) + 's'
        }
      });
      
      // 버튼 상태 복원
      runSimulationButton.disabled = false;
      runSimulationButton.textContent = '시뮬레이션 실행';
    }, 2000);
  });
  
  // 모델 선택 변경 시 파라미터 업데이트
  const modelSelect = document.getElementById('model-select');
  if (modelSelect) {
    modelSelect.addEventListener('change', updateModelParameters);
  }
  
  // 데이터셋 선택 변경 시 업로드 필드 표시/숨김
  const dataSelect = document.getElementById('data-select');
  const dataUpload = document.getElementById('data-upload');
  if (dataSelect && dataUpload) {
    dataSelect.addEventListener('change', function() {
      if (this.value === 'custom') {
        dataUpload.classList.remove('hidden');
      } else {
        dataUpload.classList.add('hidden');
      }
    });
  }
  
  // 파라미터 슬라이더 값 표시 업데이트
  const paramSliders = document.querySelectorAll('.parameter-item input[type="range"]');
  paramSliders.forEach(slider => {
    const valueDisplay = slider.nextElementSibling;
    
    // 초기값 설정
    valueDisplay.textContent = slider.value;
    
    // 값 변경 시 업데이트
    slider.addEventListener('input', function() {
      valueDisplay.textContent = this.value;
    });
  });
}

// 모델 파라미터 업데이트
function updateModelParameters() {
  const modelSelect = document.getElementById('model-select');
  const parametersContainer = document.getElementById('parameters-container');
  
  // 모델 데이터가 로드되었는지 확인
  if (Object.keys(modelsData).length === 0) {
    loadModelsData().then(() => {
      updateModelParameters();
    });
    return;
  }
  
  const selectedModel = modelSelect.value;
  const model = modelsData.models.find(m => m.id === selectedModel);
  
  if (!model) return;
  
  // 파라미터 컨테이너 초기화
  parametersContainer.innerHTML = '';
  
  // 모델 파라미터 추가
  model.parameters.forEach(param => {
    const paramItem = document.createElement('div');
    paramItem.className = 'parameter-item';
    
    // 범위형 파라미터
    if (param.range) {
      paramItem.innerHTML = `
        <label for="param-${param.name}">${param.description}</label>
        <input type="range" id="param-${param.name}" 
               min="${param.range[0]}" max="${param.range[1]}" 
               step="${(param.range[1] - param.range[0]) / 20}" 
               value="${param.default}">
        <span class="param-value">${param.default}</span>
      `;
      
      // 값 변경 이벤트 리스너
      const slider = paramItem.querySelector(`#param-${param.name}`);
      const valueDisplay = paramItem.querySelector('.param-value');
      slider.addEventListener('input', function() {
        valueDisplay.textContent = this.value;
      });
    } 
    // 옵션형 파라미터
    else if (param.options) {
      paramItem.innerHTML = `
        <label for="param-${param.name}">${param.description}</label>
        <select id="param-${param.name}" class="form-control">
          ${param.options.map(option => 
            `<option value="${option}" ${option === param.default ? 'selected' : ''}>${option}</option>`
          ).join('')}
        </select>
      `;
    }
    
    parametersContainer.appendChild(paramItem);
  });
}

// 시뮬레이션 결과 표시
function displaySimulationResults(results) {
  // 메트릭 업데이트
  document.getElementById('metric-rmse').textContent = results.metrics.rmse;
  document.getElementById('metric-mae').textContent = results.metrics.mae;
  document.getElementById('metric-r2').textContent = results.metrics.r2;
  document.getElementById('metric-time').textContent = results.metrics.time;
  
  // 예측 차트 업데이트 (Chart.js 사용)
  updatePredictionChart(results);
  
  // 변수 중요도 차트 업데이트 (Chart.js 사용)
  updateFeaturesChart(results);
  
  // 결과 해석 업데이트
  updateInterpretation(results);
}

// 예측 차트 업데이트
function updatePredictionChart(results) {
  const ctx = document.getElementById('prediction-chart');
  
  // 기존 차트 제거
  if (window.predictionChart) {
    window.predictionChart.destroy();
  }
  
  // 예시 데이터 생성
  const labels = Array.from({length: 20}, (_, i) => i + 1);
  const actualData = Array.from({length: 20}, () => Math.random() * 1000 + 500);
  const predictedData = actualData.map(val => val * (1 + (Math.random() * 0.4 - 0.2)));
  
  // 차트 생성
  window.predictionChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: labels,
      datasets: [
        {
          label: '실제 가격',
          data: actualData,
          borderColor: '#1A365D',
          backgroundColor: 'rgba(26, 54, 93, 0.1)',
          borderWidth: 2,
          pointRadius: 3,
          fill: false
        },
        {
          label: '예측 가격',
          data: predictedData,
          borderColor: '#C84B31',
          backgroundColor: 'rgba(200, 75, 49, 0.1)',
          borderWidth: 2,
          pointRadius: 3,
          fill: false
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: '실제 가격과 예측 가격 비교',
          font: {
            family: "'Noto Serif KR', serif",
            size: 16
          }
        },
        legend: {
          position: 'top'
        },
        tooltip: {
          mode: 'index',
          intersect: false
        }
      },
      scales: {
        x: {
          title: {
            display: true,
            text: '샘플 인덱스'
          }
        },
        y: {
          title: {
            display: true,
            text: '가격 (만원)'
          },
          beginAtZero: false
        }
      }
    }
  });
}

// 변수 중요도 차트 업데이트
function updateFeaturesChart(results) {
  const ctx = document.getElementById('features-chart');
  
  // 기존 차트 제거
  if (window.featuresChart) {
    window.featuresChart.destroy();
  }
  
  // 예시 데이터 생성
  const features = ['면적', '층수', '경과년수', '지하철역 거리', '학교 수', '공원 면적', '상업시설 수', '금리', '주가지수', '인구밀도'];
  const importance = Array.from({length: 10}, () => Math.random()).sort((a, b) => b - a);
  
  // 차트 생성
  window.featuresChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: features,
      datasets: [{
        label: '변수 중요도',
        data: importance,
        backgroundColor: [
          'rgba(26, 54, 93, 0.8)',
          'rgba(26, 54, 93, 0.7)',
          'rgba(26, 54, 93, 0.6)',
          'rgba(26, 54, 93, 0.5)',
          'rgba(26, 54, 93, 0.4)',
          'rgba(200, 75, 49, 0.8)',
          'rgba(200, 75, 49, 0.7)',
          'rgba(200, 75, 49, 0.6)',
          'rgba(200, 75, 49, 0.5)',
          'rgba(200, 75, 49, 0.4)'
        ],
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderWidth: 1
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        title: {
          display: true,
          text: '변수 중요도 분석',
          font: {
            family: "'Noto Serif KR', serif",
            size: 16
          }
        },
        legend: {
          display: false
        }
      },
      scales: {
        x: {
          title: {
            display: true,
            text: '변수'
          }
        },
        y: {
          title: {
            display: true,
            text: '중요도'
          },
          beginAtZero: true
        }
      }
    }
  });
}

// 결과 해석 업데이트
function updateInterpretation(results) {
  const interpretationText = document.getElementById('interpretation-text');
  
  // 모델별 해석 텍스트
  const interpretations = {
    'xgboost': `
      <p>XGBoost 모델은 RMSE ${results.metrics.rmse}, R² ${results.metrics.r2}의 성능을 보여주고 있습니다. 이는 선형 회귀 모델 대비 약 30% 향상된 예측 정확도입니다.</p>
      <p>변수 중요도 분석 결과, <strong>면적</strong>과 <strong>지하철역 거리</strong>가 가격 예측에 가장 큰 영향을 미치는 것으로 나타났습니다. 특히 면적은 전체 예측력의 약 35%를 차지하고 있어, 부동산 가격 결정에 핵심적인 요소임을 확인할 수 있습니다.</p>
      <p>예측 결과를 살펴보면, 고가 부동산(상위 10%)에서는 예측 오차가 다소 크게 나타나는 경향이 있습니다. 이는 고가 부동산의 특수한 가치 요소(조망권, 희소성 등)가 모델에 충분히 반영되지 않았기 때문으로 분석됩니다.</p>
    `,
    'lstm': `
      <p>LSTM 모델은 시계열 데이터에서 RMSE ${results.metrics.rmse}, R² ${results.metrics.r2}의 성능을 보여주고 있습니다. 특히 장기적인 가격 추세를 예측하는 데 강점을 보입니다.</p>
      <p>시계열 분석 결과, 부동산 가격은 약 24개월의 주기성을 가지고 있으며, LSTM 모델이 이러한 장기 패턴을 효과적으로 포착하고 있습니다. 특히 금리 변동과 같은 거시경제 요인이 시차를 두고 가격에 영향을 미치는 패턴을 학습했습니다.</p>
      <p>다만, 급격한 시장 변동이나 예상치 못한 외부 충격(정책 변화, 팬데믹 등)에 대한 예측력은 제한적입니다. 이는 LSTM이 과거 패턴에 기반한 예측을 수행하기 때문입니다.</p>
    `,
    'random-forest': `
      <p>Random Forest 모델은 RMSE ${results.metrics.rmse}, R² ${results.metrics.r2}의 안정적인 성능을 보여주고 있습니다. 특히 이상치에 강건한 특성을 보입니다.</p>
      <p>변수 중요도 분석 결과, <strong>면적</strong>, <strong>층수</strong>, <strong>경과년수</strong>가 상위 3개 중요 변수로 나타났습니다. 이는 부동산의 물리적 특성이 가격 결정에 큰 영향을 미친다는 것을 시사합니다.</p>
      <p>Random Forest의 앙상블 특성으로 인해 예측 결과의 분산이 작고 안정적입니다. 다만, 극단적인 고가 또는 저가 부동산의 경우 중앙값으로 회귀하는 경향이 있어, 이러한 특수 사례에 대한 예측 정확도는 다소 제한적입니다.</p>
    `,
    'svm': `
      <p>Support Vector Machine 모델은 RMSE ${results.metrics.rmse}, R² ${results.metrics.r2}의 성능을 보여주고 있습니다. RBF 커널을 사용하여 비선형 관계를 효과적으로 포착했습니다.</p>
      <p>SVM은 특히 중간 가격대 부동산에서 안정적인 예측 성능을 보이며, 이상치에 상대적으로 강건합니다. 다만, 대규모 데이터셋에서는 계산 복잡성으로 인해 학습 시간이 ${results.metrics.time}로 다소 길게 나타났습니다.</p>
      <p>하이퍼파라미터 튜닝 결과, C=${results.params.C || 10}, gamma=${results.params.gamma || 'scale'}일 때 최적의 성능을 보였습니다. 이는 적절한 정규화와 커널 스케일링이 중요함을 시사합니다.</p>
    `,
    'knn': `
      <p>k-Nearest Neighbors 모델은 RMSE ${results.metrics.rmse}, R² ${results.metrics.r2}의 성능을 보여주고 있습니다. 최적의 k값은 ${results.params.k || 5}로 나타났습니다.</p>
      <p>k-NN은 구현이 간단하고 직관적이지만, 예측 성능은 다른 복잡한 모델들에 비해 다소 제한적입니다. 특히 고차원 데이터에서 성능 저하가 관찰됩니다.</p>
      <p>이 모델은 특히 유사한 특성을 가진 부동산 식별에 유용하며, 투자 유사성 분석이나 이상치 탐지와 같은 응용 분야에 적합합니다.</p>
    `,
    'gbm': `
      <p>Gradient Boosting Machine 모델은 RMSE ${results.metrics.rmse}, R² ${results.metrics.r2}의 우수한 성능을 보여주고 있습니다.</p>
      <p>변수 중요도 분석 결과, XGBoost와 유사하게 <strong>면적</strong>과 <strong>지하철역 거리</strong>가 중요한 예측 변수로 나타났습니다. GBM은 특히 비선형 관계와 변수 간 상호작용을 효과적으로 포착합니다.</p>
      <p>학습률(learning_rate)=${results.params.learning_rate || 0.1}, 트리 개수(n_estimators)=${results.params.n_estimators || 100}일 때 최적의 성능을 보였으며, 이는 점진적 학습과 충분한 모델 복잡성이 중요함을 시사합니다.</p>
    `
  };
  
  // 선택된 모델에 따른 해석 텍스트 표시
  const modelType = results.model;
  interpretationText.innerHTML = interpretations[modelType] || `<p>선택한 모델(${modelType})의 시뮬레이션 결과입니다. RMSE ${results.metrics.rmse}, MAE ${results.metrics.mae}, R² ${results.metrics.r2}의 성능을 보여주고 있습니다.</p>`;
}

// 스크롤 이벤트 설정
function setupScrollEvents() {
  // 네비게이션 활성 항목 업데이트
  window.addEventListener('scroll', function() {
    const sections = document.querySelectorAll('.section');
    const navLinks = document.querySelectorAll('.main-nav a');
    
    let currentSection = '';
    
    sections.forEach(section => {
      const sectionTop = section.offsetTop - 100;
      const sectionHeight = section.offsetHeight;
      const sectionId = section.getAttribute('id');
      
      if (window.scrollY >= sectionTop && window.scrollY < sectionTop + sectionHeight) {
        currentSection = sectionId;
      }
    });
    
    navLinks.forEach(link => {
      link.classList.remove('active');
      if (link.getAttribute('href') === `#${currentSection}`) {
        link.classList.add('active');
      }
    });
  });
  
  // 스크롤 시 헤더 그림자 효과
  window.addEventListener('scroll', function() {
    const header = document.querySelector('.main-header');
    if (window.scrollY > 10) {
      header.style.boxShadow = 'var(--shadow-md)';
    } else {
      header.style.boxShadow = 'var(--shadow-sm)';
    }
  });
}

// 코드 복사 기능
document.addEventListener('DOMContentLoaded', function() {
  const copyButtons = document.querySelectorAll('.btn-copy');
  
  copyButtons.forEach(button => {
    button.addEventListener('click', function() {
      const targetId = this.dataset.target;
      const codeElement = document.getElementById(targetId);
      
      if (codeElement) {
        // 코드 텍스트 가져오기
        const codeText = codeElement.textContent;
        
        // 클립보드에 복사
        navigator.clipboard.writeText(codeText)
          .then(() => {
            // 복사 성공 표시
            const originalText = this.textContent;
            this.textContent = '복사 완료!';
            this.style.backgroundColor = '#4CAF50';
            this.style.color = 'white';
            
            // 2초 후 원래 상태로 복원
            setTimeout(() => {
              this.textContent = originalText;
              this.style.backgroundColor = '';
              this.style.color = '';
            }, 2000);
          })
          .catch(err => {
            console.error('클립보드 복사 실패:', err);
            alert('코드 복사에 실패했습니다. 다시 시도해주세요.');
          });
      }
    });
  });
});
